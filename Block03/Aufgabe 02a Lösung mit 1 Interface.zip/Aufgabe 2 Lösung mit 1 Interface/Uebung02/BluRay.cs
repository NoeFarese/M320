﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Uebung02
{
    public class BluRay :SpeicherMedium
    {
        //Membervariablen
        private eLayer m_Layer;
        //Konstruktoren
        public BluRay(): base(eInhalt.Daten, "")
        {
        }
        public BluRay(eInhalt inh, string tit, eLayer layer): base(inh, tit)
        {
            setLayer(layer);
        }
        //Methoden
        public void setLayer(eLayer layer)
        {
            m_Layer = layer;
        }
    }
}
