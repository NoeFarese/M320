﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Uebung02
{
    public class Hund : IBezeichnung
    {
        //Membervariablen
        private string m_Name;
        private byte m_Alter;
        private Person m_Besitzer;
        //Konstruktoren
        public Hund(string name, byte alter) {
            m_Name = name;
            m_Alter = alter;
        }
        public Hund(string name) {
            m_Name = name;
        }
        //Methoden
        public string getName()  {
            return m_Name;
        }
        public void setName(string value) {
            m_Name = value;
        }
        public byte getAlter() {
            return m_Alter;
        }
        public void setAlter(byte value){
            m_Alter = value;
        }
        public Person getBesitzer()  {
            return m_Besitzer;
        }
        public void setBesitzer(Person value) {
            m_Besitzer = value;
        }
        public string getBezeichnung() {
            return "Hund: " + m_Name + " Alter=" + m_Alter; 
        }
    }
}
