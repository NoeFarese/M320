﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Uebung02
{
    public class Person
    {
       //Membervariablen
        private string m_Name;
        private string m_Vorname;
        private List<IBezeichnung> m_Besitz = new List<IBezeichnung>();
       
        //Konstruktoren
        public Person(string name, string vorname) {
            setName(name);
            setVorname(vorname);
        }
        //Methoden
        public void setName(string value) {
            m_Name = value;
        }
        public void setVorname(string value) {
            m_Vorname = value;
        }
        public void AddBesitz(IBezeichnung value) {
            m_Besitz.Add(value);
            if (value is IHatBesitzer) {
                IHatBesitzer temp = (IHatBesitzer)value;
                temp.setBesitzer(this);
            }
        }
        public List<IBezeichnung> getBesitz() {
            return m_Besitz;
        }
        public string getFullName() {
            return m_Vorname + " " + m_Name;
        }
    }
}
