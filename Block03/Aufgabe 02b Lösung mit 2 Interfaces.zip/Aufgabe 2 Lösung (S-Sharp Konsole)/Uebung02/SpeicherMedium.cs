﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Uebung02
{
    public abstract class SpeicherMedium :IBezeichnung
    {
        //Membervariablen
        private eInhalt m_Inhalt;
        private string m_Titel;
        //Konstruktoren
        public SpeicherMedium(eInhalt Inh, string Titel) {
            setInhalt(Inh);
            setTitel(Titel);
        }
        //Methoden
        public void setInhalt(eInhalt value) {
            m_Inhalt = value;
        }
        public void setTitel(string value) {
            m_Titel = value;
        }
        public string getBezeichnung()
        {
            return m_Inhalt.ToString() + ": " + m_Titel;
        }
    }
}
