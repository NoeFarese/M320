﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Uebung02
{
    public class CompactDisc: SpeicherMedium 
    {
        //Membervariablen

        //Konstruktoren
        public CompactDisc(eInhalt inh, string tit) : base(inh, tit)
        {
        }
        //Methoden
    }
}
