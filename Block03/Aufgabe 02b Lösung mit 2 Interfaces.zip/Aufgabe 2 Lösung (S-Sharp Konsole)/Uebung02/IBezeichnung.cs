﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Uebung02
{
    public interface IBezeichnung
    {
        string getBezeichnung();
    }
}
