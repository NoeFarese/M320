using System;
using System.Collections.Generic;
using System.Text;

namespace Uebung02
{
    public enum eLayer : byte { SingleLayer = 1, DualLayer = 2 };
    public enum eInhalt : byte { Musik = 1, Film = 2, Daten = 3 };
    class Program
    {
        static void Main(string[] args) {
            SpeicherMedium r1 = new CompactDisc(eInhalt.Daten, "01.11.2008");
            CompactDisc r2 = new CompactDisc(eInhalt.Musik, "The Best of Mittelwelle 531");
            SpeicherMedium r3 = new DigitalVersatileDisc(eInhalt.Film, "Ein Quantum Trost");
            DigitalVersatileDisc r4 = new DigitalVersatileDisc();
            r4.setInhalt(eInhalt.Musik);
            r4.setTitel("mp3-Sammlung 05");
            SpeicherMedium r5 = new BluRay(eInhalt.Film, "KillBill", eLayer.SingleLayer);
            BluRay r6 = new BluRay();
            r6.setInhalt(eInhalt.Film);
            r6.setLayer(eLayer.DualLayer);
            r6.setTitel("mp3-Sammlung 05");

            Hund r7 = new Hund("Fido", 3);
            Hund r8 = new Hund("Benji");
            r8.setAlter(1);

            Katze k = new Katze("Geronimo");


            Person person = new Person("Dogfan", "Karlotta");
            person.AddBesitz(r1);
            person.AddBesitz(r2);
            person.AddBesitz(r3);
            person.AddBesitz(r4);
            person.AddBesitz(r5);
            person.AddBesitz(r6);
            person.AddBesitz(r7);
            person.AddBesitz(r8);
            person.AddBesitz(k);

            Console.WriteLine("\n----------BESITZ----------");
            foreach (IBezeichnung ib in person.getBesitz()) {
                Console.WriteLine(ib.getBezeichnung());
            }
            Console.WriteLine("\n\n----------TIERE----------");
            Console.WriteLine("Hund:" + r7.getName() + " Besitzer:" + r7.getBesitzer().getFullName());
            Console.WriteLine("Hund:" + r8.getName() + " Besitzer:" + r8.getBesitzer().getFullName());
            
            Console.WriteLine("Katze:" + k.getName() + " Besitzer:" + k.getBesitzer().getFullName());

            Console.ReadLine();
        }
    }
}
