﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Uebung02
{
    public class DigitalVersatileDisc : SpeicherMedium
    {
        //Membervariablen
       
        //Konstruktoren
        public DigitalVersatileDisc() : base(eInhalt.Daten, "")
        {
        }
        public DigitalVersatileDisc(eInhalt inh, string tit) : base(inh, tit)
        {
        }
        //Methoden
    }
}
