﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Uebung02
{
    interface IHatBesitzer
    {
        void setBesitzer(Person p);
    }
}
