﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Uebung02
{
    public class Katze:IBezeichnung, IHatBesitzer
    {
         //Membervariablen
        private string m_Name;
        private Person m_Besitzer;
        //Konstruktoren
        public Katze(string name) {
            m_Name = name;
        }
        //Methoden
        public string getName()  {
            return m_Name;
        }
        public void setName(string value) {
            m_Name = value;
        }
        public Person getBesitzer()  {
            return m_Besitzer;
        }
        public void setBesitzer(Person value) {
            m_Besitzer = value;
        }
        public string getBezeichnung() {
            return "Katze: " + m_Name; 
        }
    }
}
